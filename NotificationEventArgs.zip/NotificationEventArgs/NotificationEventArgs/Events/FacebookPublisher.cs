﻿using System;
using System.Threading;

namespace NotificationEventArgs.Events
{
    public class FacebookPublisher
    {
        // Declare the event using EventHandler<T>
        public event EventHandler<NotificationEventArgs> NotificationSent;

        // Use a private field to store the event handler
        private EventHandler<NotificationEventArgs> _notificationSent;

        // A lock object for thread safety
        private readonly object _lock = new object();

        // Add an event subscriber
        public void Subscribe(EventHandler<NotificationEventArgs> handler)
        {
            if (handler == null) throw new ArgumentNullException(nameof(handler));

            lock (_lock)
            {
                _notificationSent += handler;
            }
        }

        // Remove an event subscriber
        public void Unsubscribe(EventHandler<NotificationEventArgs> handler)
        {
            if (handler == null) throw new ArgumentNullException(nameof(handler));

            lock (_lock)
            {
                _notificationSent -= handler;
            }
        }

        // Trigger the event
        public void PublishNotification(string message)
        {
            EventHandler<NotificationEventArgs> handler;

            lock (_lock)
            {
                handler = _notificationSent;
            }

            if (handler != null)
            {
                var eventArgs = new NotificationEventArgs(message, DateTime.Now);
                try
                {
                    handler(this, eventArgs);
                }
                catch (Exception ex)
                {
                    // Handle the exception, log it, etc.
                    Console.WriteLine($"Error while notifying subscribers: {ex.Message}");
                }
            }
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using NotificationEventArgs.Events;

namespace NotificationEventArgs.Controllers
{
    public class NotificationController : Controller
    {
        private static readonly FacebookPublisher _publisher = new FacebookPublisher();

        static NotificationController()
        {
            _publisher.Subscribe(OnNotificationSent);
        }

        private static void OnNotificationSent(object? sender, Events.NotificationEventArgs e)
        {
            throw new NotImplementedException();
        }

        // GET: Notification/SendNotification
        public IActionResult SendNotification()
        {
            return View();
        }

        // POST: Notification/SendNotification
        [HttpPost]
        public IActionResult SendNotification(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                ModelState.AddModelError("Message", "Message cannot be empty");
                return View();
            }

            _publisher.PublishNotification(message);
            ViewBag.Message = "Notification sent successfully!";
            return View();
        }

    }
}
